// Land Size Unit Converter - Popup Script

const unitSelect = document.getElementById('unitSelect');
const domainsTextarea = document.getElementById('allowedDomains');
const addSiteBtn = document.getElementById('addSiteBtn');
const saveBtn = document.getElementById('saveBtn');
const saveIndicator = document.getElementById('saveIndicator');

// The hostname of the active tab (set once on popup open)
let activeTabHostname = null;
let activeTabId = null;

// Load saved preferences
chrome.storage.sync.get(['preferredUnit', 'allowedDomains'], (result) => {
  unitSelect.value = result.preferredUnit || 'm2';

  const domains = result.allowedDomains || 'domain.com.au, realestate.com.au';
  domainsTextarea.value = domains;

  // After loading domains, check if current site is already listed
  updateAddSiteButton(domains);
});

// Query the active tab to get its hostname
chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
  if (!tabs[0]?.url) return;
  try {
    const url = new URL(tabs[0].url);
    activeTabHostname = url.hostname;
    activeTabId = tabs[0].id;
    updateAddSiteButton(domainsTextarea.value);
  } catch {
    // Non-standard URL (chrome://, about:, etc.) — hide the button
    addSiteBtn.style.display = 'none';
  }
});

// Show/hide/update the "Add this Site" button based on whether the domain is already listed
function updateAddSiteButton(domainsString) {
  if (!activeTabHostname) return;

  const list = domainsString.split(',').map(d => d.trim()).filter(Boolean);
  const alreadyListed = list.some(domain => activeTabHostname.endsWith(domain));

  if (alreadyListed) {
    addSiteBtn.textContent = '✓ Site added';
    addSiteBtn.classList.add('added');
  } else {
    addSiteBtn.textContent = '+ Add this Site';
    addSiteBtn.classList.remove('added');
  }
}

// Handle "Add this Site" click
addSiteBtn.addEventListener('click', () => {
  if (!activeTabHostname) return;

  // Read current list, append, deduplicate
  const current = domainsTextarea.value.trim();
  const list = current.split(',').map(d => d.trim()).filter(Boolean);

  // Don't add if already present
  if (list.some(domain => activeTabHostname.endsWith(domain))) return;

  list.push(activeTabHostname);
  const updated = list.join(', ');
  domainsTextarea.value = updated;

  // Save immediately, then reload so background worker injects the content script
  chrome.storage.sync.set({ allowedDomains: updated }, () => {
    updateAddSiteButton(updated);

    saveIndicator.classList.add('show');
    setTimeout(() => saveIndicator.classList.remove('show'), 2000);

    if (activeTabId) {
      chrome.tabs.reload(activeTabId);
    }
  });
});

// Handle Save button click
saveBtn.addEventListener('click', () => {
  chrome.storage.sync.set({
    preferredUnit: unitSelect.value,
    allowedDomains: domainsTextarea.value
  }, () => {
    saveIndicator.classList.add('show');
    setTimeout(() => saveIndicator.classList.remove('show'), 2000);
  });
});
