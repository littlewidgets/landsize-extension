// Land Size Unit Converter - Content Script
// Only injected by background.js on allowed domains.

// Guard against double-injection
if (window.__landSizeConverterInjected) {
  // Already running — skip
} else {
  window.__landSizeConverterInjected = true;

  // Conversion constants
  const CONVERSIONS = {
    m2_to_ha: 0.0001,
    m2_to_ac: 0.000247105,
    ha_to_m2: 10000,
    ha_to_ac: 2.47105,
    ac_to_m2: 4046.86,
    ac_to_ha: 0.404686
  };

  // Unit display names
  const UNIT_NAMES = { m2: 'm²', ha: 'ha', ac: 'ac' };

  // Unit rotation order
  const UNIT_ORDER = ['m2', 'ha', 'ac'];

  // The current display unit for all values (starts as preferred, then follows clicks)
  let currentDisplayUnit = null;

  // User's preferred unit from settings
  let preferredUnit = 'm2';

  // Track processed nodes to avoid reprocessing
  const processedNodes = new WeakSet();

  // Regex pattern for land size detection
  // Matches: 500 m², 2.5 hectares, 100 acres, 1,234.56 ha, 5000 sqm, 16-acre, 16-acres, etc.
  const LAND_SIZE_PATTERN = /(\d{1,3}(?:,?\d{3})*(?:\.\d+)?)[\s-]*(m²|m2|sqm|sq\.?\s*m(?:eters?|etres?)?|hectares?|ha|acres?|ac)(?!\w)/gi;

  // Convert value between units
  function convertValue(value, fromUnit, toUnit) {
    if (fromUnit === toUnit) return value;
    const key = `${fromUnit}_to_${toUnit}`;
    const factor = CONVERSIONS[key];
    if (!factor) return value;
    return value * factor;
  }

  // Format a numeric result for display
  function formatValue(value) {
    if (value < 0.01) return value.toFixed(4);
    if (value < 1) return value.toFixed(3);
    if (value < 100) return value.toFixed(2);
    if (value < 1000) return value.toFixed(1);
    return Math.round(value).toLocaleString();
  }

  // Format number with commas (for original values)
  function formatNumber(num) {
    return parseFloat(num).toLocaleString();
  }

  // Parse number from text (handle commas)
  function parseNumber(text) {
    return parseFloat(text.replace(/,/g, ''));
  }

  // Get the next unit in rotation
  function getNextUnit(currentUnit) {
    const idx = UNIT_ORDER.indexOf(currentUnit);
    return UNIT_ORDER[(idx + 1) % UNIT_ORDER.length];
  }

  // Normalise a matched unit string to our internal key
  function normaliseUnit(unitText) {
    const u = unitText.toLowerCase().trim();
    if (u === 'm²' || u === 'm2' || u === 'sqm' || u.startsWith('sq')) return 'm2';
    if (u === 'ha' || u.startsWith('hectare')) return 'ha';
    if (u === 'ac' || u.startsWith('acre')) return 'ac';
    return null;
  }

  // Build the display string for a value+unit
  function displayText(originalValue, originalUnit, displayUnit) {
    if (displayUnit === originalUnit) {
      return `${formatNumber(originalValue)} ${UNIT_NAMES[originalUnit]}`;
    }
    const converted = convertValue(originalValue, originalUnit, displayUnit);
    return `${formatValue(converted)} ${UNIT_NAMES[displayUnit]}`;
  }

  // Update all existing converted spans to a given display unit
  function updateAllSpans(unit) {
    document.querySelectorAll('.land-size-wrapper').forEach(wrapper => {
      const span = wrapper.querySelector('.land-size-value');
      const originalValue = parseFloat(wrapper.dataset.originalValue);
      const originalUnit = wrapper.dataset.originalUnit;
      if (!span || isNaN(originalValue) || !originalUnit) return;

      span.dataset.currentUnit = unit;
      span.textContent = displayText(originalValue, originalUnit, unit);
    });
  }

  // Scan and convert all land sizes on the page
  function scanAndConvert() {
    const walker = document.createTreeWalker(
      document.body,
      NodeFilter.SHOW_TEXT,
      {
        acceptNode(node) {
          if (processedNodes.has(node)) return NodeFilter.FILTER_SKIP;
          if (!node.parentElement) return NodeFilter.FILTER_SKIP;
          const tag = node.parentElement.tagName;
          if (tag === 'SCRIPT' || tag === 'STYLE' || tag === 'TEXTAREA' || tag === 'INPUT')
            return NodeFilter.FILTER_SKIP;
          if (node.parentElement.closest('.land-size-wrapper'))
            return NodeFilter.FILTER_SKIP;
          return NodeFilter.FILTER_ACCEPT;
        }
      }
    );

    const nodesToProcess = [];
    let node;
    while ((node = walker.nextNode())) {
      LAND_SIZE_PATTERN.lastIndex = 0;
      if (LAND_SIZE_PATTERN.test(node.textContent)) {
        nodesToProcess.push(node);
      }
    }

    const unit = currentDisplayUnit || preferredUnit;

    nodesToProcess.forEach(textNode => {
      processedNodes.add(textNode);

      const text = textNode.textContent;
      const parent = textNode.parentNode;
      if (!parent || parent.tagName === 'SCRIPT' || parent.tagName === 'STYLE') return;

      const fragment = document.createDocumentFragment();
      let lastIndex = 0;
      let match;
      const regex = new RegExp(LAND_SIZE_PATTERN.source, LAND_SIZE_PATTERN.flags);

      while ((match = regex.exec(text)) !== null) {
        if (match.index > lastIndex) {
          fragment.appendChild(document.createTextNode(text.substring(lastIndex, match.index)));
        }

        const value = parseNumber(match[1]);
        const originalUnit = normaliseUnit(match[2]);

        if (!originalUnit) {
          fragment.appendChild(document.createTextNode(match[0]));
          lastIndex = regex.lastIndex;
          continue;
        }

        const wrapper = document.createElement('span');
        wrapper.className = 'land-size-wrapper';
        wrapper.dataset.originalValue = value.toString();
        wrapper.dataset.originalUnit = originalUnit;

        const landSizeSpan = document.createElement('span');
        landSizeSpan.className = 'land-size-value';
        landSizeSpan.dataset.currentUnit = unit;
        landSizeSpan.textContent = displayText(value, originalUnit, unit);

        landSizeSpan.addEventListener('click', handleClick);
        landSizeSpan.addEventListener('mouseenter', showTooltip);
        landSizeSpan.addEventListener('mouseleave', hideTooltip);

        wrapper.appendChild(landSizeSpan);
        fragment.appendChild(wrapper);
        lastIndex = regex.lastIndex;
      }

      if (lastIndex < text.length) {
        fragment.appendChild(document.createTextNode(text.substring(lastIndex)));
      }

      if (fragment.childNodes.length > 0) {
        try {
          parent.replaceChild(fragment, textNode);
        } catch (e) {
          // Node may have already been replaced
        }
      }
    });
  }

  // Handle click to rotate units globally
  function handleClick(e) {
    e.preventDefault();
    e.stopPropagation();

    const span = e.target;
    const current = span.dataset.currentUnit;
    if (!current) return;

    const nextUnit = getNextUnit(current);
    currentDisplayUnit = nextUnit;
    updateAllSpans(nextUnit);
  }

  // Show tooltip on hover
  function showTooltip(e) {
    const span = e.target;
    const wrapper = span.closest('.land-size-wrapper');
    if (!wrapper) return;

    const originalValue = parseFloat(wrapper.dataset.originalValue);
    const originalUnit = wrapper.dataset.originalUnit;
    if (isNaN(originalValue) || !originalUnit) return;

    hideTooltip();

    const tooltip = document.createElement('div');
    tooltip.className = 'land-size-tooltip';

    UNIT_ORDER.forEach(unit => {
      const row = document.createElement('div');
      row.className = 'tooltip-row';
      if (unit === originalUnit) row.classList.add('original');

      const valSpan = document.createElement('span');
      valSpan.className = 'tooltip-value';
      if (unit === originalUnit) {
        valSpan.textContent = formatNumber(originalValue);
      } else {
        valSpan.textContent = formatValue(convertValue(originalValue, originalUnit, unit));
      }

      const unitSpan = document.createElement('span');
      unitSpan.className = 'tooltip-unit';
      unitSpan.textContent = UNIT_NAMES[unit];

      row.appendChild(valSpan);
      row.appendChild(unitSpan);

      if (unit === originalUnit) {
        const origLabel = document.createElement('span');
        origLabel.className = 'tooltip-original';
        origLabel.textContent = '(original)';
        row.appendChild(origLabel);
      }

      tooltip.appendChild(row);
    });

    document.body.appendChild(tooltip);

    const rect = span.getBoundingClientRect();
    const tooltipRect = tooltip.getBoundingClientRect();

    let top = rect.top + window.scrollY - tooltipRect.height - 8;
    let left = rect.left + window.scrollX + (rect.width - tooltipRect.width) / 2;

    if (top < window.scrollY) {
      top = rect.bottom + window.scrollY + 8;
    }
    if (left < 0) left = 8;
    if (left + tooltipRect.width > window.innerWidth) {
      left = window.innerWidth - tooltipRect.width - 8;
    }

    tooltip.style.top = top + 'px';
    tooltip.style.left = left + 'px';
  }

  // Hide tooltip
  function hideTooltip() {
    const existing = document.querySelector('.land-size-tooltip');
    if (existing) existing.remove();
  }

  // Observer for dynamic content (lazy-loaded listings, AJAX, etc.)
  const observer = new MutationObserver(mutations => {
    let shouldRescan = false;
    for (const mutation of mutations) {
      if (mutation.type !== 'childList' || !mutation.addedNodes.length) continue;
      for (const added of mutation.addedNodes) {
        if (added.nodeType === Node.ELEMENT_NODE &&
            added.classList &&
            (added.classList.contains('land-size-tooltip') ||
             added.classList.contains('land-size-wrapper'))) {
          continue;
        }
        shouldRescan = true;
        break;
      }
      if (shouldRescan) break;
    }
    if (shouldRescan) {
      setTimeout(scanAndConvert, 100);
    }
  });

  // --- Initialisation ---

  // Load preferred unit, then scan
  chrome.storage.sync.get(['preferredUnit'], result => {
    if (result.preferredUnit) preferredUnit = result.preferredUnit;
    scanAndConvert();
    observer.observe(document.body, { childList: true, subtree: true });
  });

  // Listen for settings changes (e.g. user changes preferred unit while page is open)
  chrome.storage.onChanged.addListener((changes, namespace) => {
    if (namespace !== 'sync') return;
    if (changes.preferredUnit) {
      preferredUnit = changes.preferredUnit.newValue;
      if (!currentDisplayUnit) {
        updateAllSpans(preferredUnit);
      }
    }
  });
}
