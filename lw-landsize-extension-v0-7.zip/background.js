// Land Size Unit Converter - Background Service Worker
// Handles programmatic injection of content script on allowed domains only.

// Parse the allowed domains string into an array
function parseDomains(raw) {
  if (!raw) return ['domain.com.au', 'realestate.com.au'];
  return raw.split(',').map(d => d.trim()).filter(Boolean);
}

// Check if a hostname matches an allowed domain
function isAllowedDomain(hostname, domains) {
  return domains.some(domain => hostname.endsWith(domain));
}

// Inject content script + CSS into a tab
async function injectIfAllowed(tabId, url) {
  let hostname;
  try {
    hostname = new URL(url).hostname;
  } catch {
    return; // chrome://, about:, etc.
  }

  const result = await chrome.storage.sync.get(['allowedDomains']);
  const domains = parseDomains(result.allowedDomains);

  if (!isAllowedDomain(hostname, domains)) return;

  // Check if already injected by looking for a marker
  try {
    const [{ result: alreadyInjected }] = await chrome.scripting.executeScript({
      target: { tabId },
      func: () => !!document.querySelector('.land-size-wrapper') || !!window.__landSizeConverterInjected
    });
    if (alreadyInjected) return;
  } catch {
    return; // Tab not accessible (e.g. chrome:// pages)
  }

  try {
    // Inject CSS first, then JS
    await chrome.scripting.insertCSS({
      target: { tabId },
      files: ['content.css']
    });
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ['content.js']
    });
  } catch {
    // Injection failed — tab may not be injectable
  }
}

// Listen for page navigations (complete = DOM ready)
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && tab.url) {
    injectIfAllowed(tabId, tab.url);
  }
});

// Listen for messages from the popup (e.g. after "Add this Site")
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'injectTab' && message.tabId) {
    injectIfAllowed(message.tabId, message.url);
  }
});
